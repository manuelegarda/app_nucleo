var ruta="http://localhost/ModLogin/php/";
$(document).ready(function()
 {
 		 $.ajax({
            type: 'post',
            url: ruta+"Main.php",
            data: {peticion:6},
            dataType: "html",
            success: function(data) {
 			$('#lista').append(data);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("Error detectado: " + jqXHR[0] + "\n Excepcion: " + errorThrown);
            }
        });	
         $.ajax({
            type: 'post',
            url: ruta+"MainSimposio.php",
            data: {peticion:6},
            dataType: "html",
            success: function(data) {
            $('#listaSimpo').append(data);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("Error detectado: " + jqXHR[0] + "\n Excepcion: " + errorThrown);
            }
        });


});

